# Signage Player — R8 rules
# The app uses no reflection or JavaScript interfaces, so default rules are enough.
# Keep line numbers for readable crash logs.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Keep WebView client callbacks (overridden framework methods are kept by default, this is a safety net)
-keepclassmembers class * extends android.webkit.WebViewClient { public *; }
-keepclassmembers class * extends android.webkit.WebChromeClient { public *; }

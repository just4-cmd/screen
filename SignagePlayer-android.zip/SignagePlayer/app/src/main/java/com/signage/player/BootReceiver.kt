package com.signage.player

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * Opens the player automatically:
 *  - after the device boots (power restored)          → BOOT_COMPLETED / QUICKBOOT_POWERON
 *  - after the app is updated to a new version         → MY_PACKAGE_REPLACED
 *
 * Android 10+ blocks activity starts from the background unless the app holds
 * "Display over other apps" (SYSTEM_ALERT_WINDOW). If it does not, we fall back to a
 * full-screen-intent notification, which opens the player when the device is idle/locked.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "SignageBoot"
        private const val CHANNEL_ID = "signage_autostart"
        private const val NOTIFICATION_ID = 1001

        private val HANDLED_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON"
        )

        fun launchIntent(context: Context): Intent =
            Intent(context, MainActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
            )

        fun cancelLaunchNotification(context: Context) {
            try {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(NOTIFICATION_ID)
            } catch (_: Throwable) {
            }
        }

        private fun canStartFromBackground(context: Context): Boolean =
            Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(context)

        private fun showFullScreenLaunchNotification(context: Context) {
            try {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= 26) {
                    val channel = NotificationChannel(
                        CHANNEL_ID,
                        context.getString(R.string.autostart_channel),
                        NotificationManager.IMPORTANCE_HIGH
                    )
                    channel.setShowBadge(false)
                    nm.createNotificationChannel(channel)
                }
                val pending = PendingIntent.getActivity(
                    context,
                    0,
                    launchIntent(context),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle(context.getString(R.string.app_name))
                    .setContentText(context.getString(R.string.tap_to_start))
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setFullScreenIntent(pending, true)
                    .setContentIntent(pending)
                    .setAutoCancel(true)
                    .build()
                nm.notify(NOTIFICATION_ID, notification)
            } catch (e: Throwable) {
                Log.w(TAG, "Could not post launch notification", e)
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action !in HANDLED_ACTIONS) return
        Log.i(TAG, "Received $action → launching player")

        try {
            context.startActivity(launchIntent(context))
        } catch (e: Throwable) {
            Log.w(TAG, "Direct start failed", e)
        }

        if (!canStartFromBackground(context)) {
            showFullScreenLaunchNotification(context)
        }

        // Second attempt a few seconds later: some TV boxes send BOOT_COMPLETED before
        // the launcher/WebView are ready. Harmless if the player is already in front (singleTask).
        try {
            MainActivity.scheduleRelaunch(context.applicationContext, 8_000L)
        } catch (e: Throwable) {
            Log.w(TAG, "Could not schedule relaunch", e)
        }
    }
}

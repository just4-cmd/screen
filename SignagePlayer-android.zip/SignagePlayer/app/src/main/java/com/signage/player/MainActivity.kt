package com.signage.player

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.ServiceWorkerClientCompat
import androidx.webkit.ServiceWorkerControllerCompat
import androidx.webkit.WebViewFeature
import kotlin.system.exitProcess

/**
 * Full-screen kiosk WebView for a Digital Signage player page.
 *
 *  - Immersive sticky fullscreen, screen always on (window flag + wake lock)
 *  - JS, DOM storage, IndexedDB/WebSQL, Service Workers, autoplay without gesture
 *  - Hidden scrollbars and mouse cursor
 *  - First-run URL dialog; secret re-open: 5 taps in the top-left corner, or MENU / 0 on a remote
 *  - No Android error page: black overlay + automatic retry every 10 s (cache-first while offline)
 *  - Watchdogs: renderer crash (OOM) recovery, hung-renderer heartbeat, app-crash auto relaunch
 */
class MainActivity : Activity() {

    companion object {
        private const val TAG = "SignagePlayer"

        const val PREFS = "signage_prefs"
        const val KEY_URL = "server_url"

        private const val RETRY_INTERVAL_MS = 10_000L
        private const val LOAD_TIMEOUT_MS = 30_000L
        private const val WATCHDOG_INTERVAL_MS = 30_000L
        private const val WATCHDOG_TIMEOUT_MS = 95_000L

        private const val SECRET_TAPS = 5
        private const val SECRET_TAP_WINDOW_MS = 3_000L
        private const val SECRET_CORNER_DP = 100

        private const val MAX_RENDERER_CRASHES = 5
        private const val RENDERER_CRASH_WINDOW_MS = 5 * 60_000L

        private const val REQ_NOTIFICATIONS = 42

        private const val KIOSK_CSS_JS = """
            (function () {
              var id = '__signage_kiosk_css';
              if (document.getElementById(id)) return;
              var s = document.createElement('style');
              s.id = id;
              s.textContent =
                '*, *::before, *::after { cursor: none !important; }' +
                '::-webkit-scrollbar { display: none !important; width: 0 !important; height: 0 !important; }' +
                'html, body { scrollbar-width: none !important; -ms-overflow-style: none !important; }';
              (document.head || document.documentElement).appendChild(s);
            })();
        """

        @Volatile
        private var crashHandlerInstalled = false

        /** Re-open the player after [delayMs] (used after a fatal crash or as a second boot attempt). */
        fun scheduleRelaunch(context: Context, delayMs: Long) {
            val intent = Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pending = PendingIntent.getActivity(
                context,
                1,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarm.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + delayMs, pending)
        }
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var overlay: LinearLayout
    private lateinit var overlayText: TextView
    private lateinit var overlayHint: TextView

    private var webView: WebView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var settingsDialog: AlertDialog? = null

    /** True while the player page could not be loaded at all (overlay visible, retry loop running). */
    private var pageFailed = false
    /** True if the current main-frame navigation reported an error. */
    private var currentLoadFailed = false
    private var isLoading = false
    private var loadStartedAt = 0L
    private var lastHeartbeatAt = 0L

    private var tapCount = 0
    private var firstTapAt = 0L
    private val rendererCrashTimes = ArrayDeque<Long>()

    // ─────────────────────────── Lifecycle ───────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashHandler()
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        configureWindow()
        buildLayout()
        configureServiceWorkers()
        createWebView()
        acquireWakeLock()
        registerNetworkCallback()
        BootReceiver.cancelLaunchNotification(this)

        if (serverUrl() == null) {
            showOverlay(getString(R.string.not_configured))
            showSettingsDialog(firstRun = true)
        } else {
            loadServer()
        }
        handler.postDelayed(watchdogRunnable, WATCHDOG_INTERVAL_MS)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        BootReceiver.cancelLaunchNotification(this)
        if (webView == null) {
            createWebView()
            loadServer()
        }
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
        webView?.resumeTimers()
        acquireWakeLock()
        hideSystemBars()
    }

    // NOTE: onPause intentionally does NOT pause the WebView — signage must keep playing
    // even if a system dialog or overlay steals focus.

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        unregisterNetworkCallback()
        releaseWakeLock()
        settingsDialog?.dismiss()
        destroyWebView()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Kiosk: Back does nothing.
    }

    // ─────────────────────────── Window / fullscreen ───────────────────────────

    @Suppress("DEPRECATION")
    private fun configureWindow() {
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_FULLSCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        )
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        if (Build.VERSION.SDK_INT >= 28) {
            val attrs = window.attributes
            attrs.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = attrs
        }
        window.decorView.setBackgroundColor(Color.BLACK)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        // Bars re-appear after a swipe → hide them again shortly after (sticky behaviour on all versions)
        window.decorView.setOnSystemUiVisibilityChangeListener { visibility ->
            if ((visibility and View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) {
                handler.postDelayed({ hideSystemBars() }, 1500)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (Build.VERSION.SDK_INT < 30) {
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                )
        }
    }

    private fun buildLayout() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            keepScreenOn = true
        }

        overlayText = TextView(this).apply {
            setTextColor(0xFF94A3B8.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }
        overlayHint = TextView(this).apply {
            setTextColor(0xFF475569.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(16), dp(24), dp(8))
            text = getString(R.string.secret_hint)
        }
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            addView(overlayText)
            addView(overlayHint)
        }
        root.addView(
            overlay,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)
        hidePointer(root)
        hidePointer(overlay)
    }

    private fun hidePointer(view: View) {
        if (Build.VERSION.SDK_INT >= 24) {
            view.pointerIcon = PointerIcon.getSystemIcon(this, PointerIcon.TYPE_NULL)
        }
    }

    private fun showOverlay(message: String) {
        overlayText.text = message
        overlay.visibility = View.VISIBLE
        overlay.bringToFront()
    }

    private fun hideOverlay() {
        overlay.visibility = View.GONE
    }

    // ─────────────────────────── WebView ───────────────────────────

    private fun configureServiceWorkers() {
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_BASIC_USAGE)) return
            val controller = ServiceWorkerControllerCompat.getInstance()
            controller.setServiceWorkerClient(object : ServiceWorkerClientCompat() {
                override fun shouldInterceptRequest(request: WebResourceRequest): WebResourceResponse? = null
            })
            val swSettings = controller.serviceWorkerWebSettings
            if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_CACHE_MODE)) {
                swSettings.cacheMode = WebSettings.LOAD_DEFAULT
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_CONTENT_ACCESS)) {
                swSettings.allowContentAccess = true
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_BLOCK_NETWORK_LOADS)) {
                swSettings.blockNetworkLoads = false
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Service worker setup failed", e)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    private fun createWebView() {
        val wv = WebView(this)
        wv.setBackgroundColor(Color.BLACK)
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.isFocusable = true
        wv.isFocusableInTouchMode = true
        wv.keepScreenOn = true
        wv.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        hidePointer(wv)

        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.userAgentString = s.userAgentString + " SignageKiosk/" + BuildConfig.VERSION_NAME
        if (Build.VERSION.SDK_INT >= 23) s.offscreenPreRaster = true
        if (Build.VERSION.SDK_INT >= 26) s.safeBrowsingEnabled = false

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)

        wv.webViewClient = KioskWebViewClient()
        wv.webChromeClient = KioskChromeClient()

        root.addView(
            wv,
            0,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        wv.requestFocus()
        webView = wv
        lastHeartbeatAt = 0L
    }

    private fun destroyWebView() {
        val wv = webView ?: return
        webView = null
        try {
            root.removeView(wv)
            wv.stopLoading()
            wv.webChromeClient = null
            wv.webViewClient = WebViewClient()
            wv.destroy()
        } catch (e: Throwable) {
            Log.w(TAG, "destroyWebView", e)
        }
    }

    private fun recreateWebView(reason: String) {
        Log.w(TAG, "Recreating WebView: $reason")
        destroyWebView()
        createWebView()
        loadServer()
    }

    private fun serverUrl(): String? = prefs.getString(KEY_URL, null)?.takeIf { it.isNotBlank() }

    private fun loadServer() {
        val url = serverUrl() ?: return
        val wv = webView ?: return
        // Offline → let the HTTP cache serve the page even if stale; online → normal revalidation.
        wv.settings.cacheMode = if (isOnline()) WebSettings.LOAD_DEFAULT else WebSettings.LOAD_CACHE_ELSE_NETWORK
        if (pageFailed) showOverlay(getString(R.string.connecting, url))
        isLoading = true
        loadStartedAt = SystemClock.elapsedRealtime()
        Log.i(TAG, "Loading $url (cacheMode=${wv.settings.cacheMode})")
        wv.loadUrl(url)
    }

    private fun onLoadSucceeded() {
        if (pageFailed) Log.i(TAG, "Page loaded, leaving retry mode")
        pageFailed = false
        handler.removeCallbacks(retryRunnable)
        hideOverlay()
        lastHeartbeatAt = SystemClock.elapsedRealtime()
    }

    private fun onMainFrameError(view: WebView?, description: String) {
        Log.w(TAG, "Main frame failed: $description")
        currentLoadFailed = true
        pageFailed = true
        isLoading = false
        // Replace Android's built-in error page with a plain black page under our overlay.
        try {
            view?.stopLoading()
            view?.loadDataWithBaseURL(null, "<html><body style=\"background:#000\"></body></html>", "text/html", "utf-8", null)
        } catch (_: Throwable) {
        }
        showOverlay(getString(R.string.connecting, serverUrl() ?: ""))
        scheduleRetry()
    }

    private val retryRunnable = object : Runnable {
        override fun run() {
            if (!pageFailed) return
            val stuck = isLoading && SystemClock.elapsedRealtime() - loadStartedAt < LOAD_TIMEOUT_MS
            if (!stuck) loadServer()
            handler.postDelayed(this, RETRY_INTERVAL_MS)
        }
    }

    private fun scheduleRetry() {
        handler.removeCallbacks(retryRunnable)
        handler.postDelayed(retryRunnable, RETRY_INTERVAL_MS)
    }

    private fun injectKioskCss(view: WebView?) {
        try {
            view?.evaluateJavascript(KIOSK_CSS_JS, null)
        } catch (_: Throwable) {
        }
    }

    private fun isHttpUrl(url: String?): Boolean =
        url != null && (url.startsWith("http://", true) || url.startsWith("https://", true))

    private inner class KioskWebViewClient : WebViewClient() {

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            if (isHttpUrl(url)) {
                currentLoadFailed = false
                isLoading = true
                loadStartedAt = SystemClock.elapsedRealtime()
            }
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            if (!isHttpUrl(url)) return
            isLoading = false
            injectKioskCss(view)
            if (!currentLoadFailed) onLoadSucceeded()
        }

        // API 23+
        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            if (request?.isForMainFrame == true) {
                onMainFrameError(view, "${error?.errorCode} ${error?.description}")
            }
        }

        // API 21-22
        @Deprecated("Deprecated in Java")
        @Suppress("DEPRECATION")
        override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
            if (Build.VERSION.SDK_INT < 23) onMainFrameError(view, "$errorCode $description")
        }

        // 4xx/5xx on the page itself (e.g. 502 while the server container restarts)
        override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
            val code = errorResponse?.statusCode ?: return
            if (request?.isForMainFrame == true && code >= 400) {
                onMainFrameError(view, "HTTP $code")
            }
        }

        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
            !isHttpUrl(request?.url?.toString())

        @Deprecated("Deprecated in Java")
        @Suppress("DEPRECATION")
        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = !isHttpUrl(url)

        // Watchdog: WebView renderer killed (out of memory) or crashed → rebuild it.
        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            val crashed = if (Build.VERSION.SDK_INT >= 26) detail?.didCrash() ?: false else false
            Log.e(TAG, "WebView renderer gone (crashed=$crashed)")
            handleRendererGone()
            return true // we handled it — do not kill the app
        }
    }

    private inner class KioskChromeClient : WebChromeClient() {
        // Transparent poster: avoids the grey "play" placeholder before a <video> starts.
        override fun getDefaultVideoPoster(): Bitmap? = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
            consoleMessage?.let { Log.d(TAG, "console: ${it.message()} (${it.sourceId()}:${it.lineNumber()})") }
            return true
        }
    }

    private fun handleRendererGone() {
        val now = SystemClock.elapsedRealtime()
        rendererCrashTimes.addLast(now)
        while (rendererCrashTimes.isNotEmpty() && now - rendererCrashTimes.first() > RENDERER_CRASH_WINDOW_MS) {
            rendererCrashTimes.removeFirst()
        }
        // The dead WebView must be removed and destroyed before anything else touches it.
        destroyWebView()
        if (rendererCrashTimes.size >= MAX_RENDERER_CRASHES) {
            Log.e(TAG, "Too many renderer crashes → restarting the whole app")
            restartApp()
            return
        }
        handler.postDelayed({
            createWebView()
            loadServer()
        }, 1000)
    }

    // ─────────────────────────── Watchdog ───────────────────────────

    private val watchdogRunnable = object : Runnable {
        override fun run() {
            try {
                val wv = webView
                if (wv != null && !pageFailed && serverUrl() != null && lastHeartbeatAt > 0) {
                    val silentFor = SystemClock.elapsedRealtime() - lastHeartbeatAt
                    if (silentFor > WATCHDOG_TIMEOUT_MS) {
                        // JS engine did not answer for too long → renderer is hung
                        recreateWebView("renderer not responding for ${silentFor / 1000}s")
                    } else {
                        wv.evaluateJavascript("1") { lastHeartbeatAt = SystemClock.elapsedRealtime() }
                    }
                }
                if (webView == null && serverUrl() != null) {
                    createWebView()
                    loadServer()
                }
                if (settingsDialog?.isShowing != true) hideSystemBars()
                acquireWakeLock()
            } catch (e: Throwable) {
                Log.e(TAG, "watchdog error", e)
            }
            handler.postDelayed(this, WATCHDOG_INTERVAL_MS)
        }
    }

    private fun restartApp() {
        scheduleRelaunch(applicationContext, 2000)
        finishAffinity()
        Process.killProcess(Process.myPid())
        exitProcess(0)
    }

    private fun installCrashHandler() {
        if (crashHandlerInstalled) return
        crashHandlerInstalled = true
        Thread.setDefaultUncaughtExceptionHandler { _, throwable ->
            Log.e(TAG, "Fatal crash — relaunching in 3s", throwable)
            try {
                scheduleRelaunch(applicationContext, 3000)
            } catch (_: Throwable) {
            }
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }

    // ─────────────────────────── Network ───────────────────────────

    @Suppress("DEPRECATION")
    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return try {
            if (Build.VERSION.SDK_INT >= 23) {
                val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (_: Throwable) {
            true // unknown → try the network
        }
    }

    private fun registerNetworkCallback() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                handler.post { onNetworkAvailable() }
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                cm.registerDefaultNetworkCallback(callback)
            } else {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(request, callback)
            }
            networkCallback = callback
        } catch (e: Throwable) {
            Log.w(TAG, "registerNetworkCallback failed", e)
        }
    }

    private fun unregisterNetworkCallback() {
        val cb = networkCallback ?: return
        networkCallback = null
        try {
            (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(cb)
        } catch (_: Throwable) {
        }
    }

    private fun onNetworkAvailable() {
        Log.i(TAG, "Network available")
        // Back to normal cache revalidation (a running page keeps working on its own).
        webView?.settings?.cacheMode = WebSettings.LOAD_DEFAULT
        if (pageFailed) {
            handler.removeCallbacks(retryRunnable)
            handler.postDelayed(retryRunnable, 1500)
        }
    }

    // ─────────────────────────── Wake lock ───────────────────────────

    @SuppressLint("WakelockTimeout")
    @Suppress("DEPRECATION")
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                    PowerManager.ACQUIRE_CAUSES_WAKEUP or
                    PowerManager.ON_AFTER_RELEASE,
                "SignagePlayer:screen"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Throwable) {
            Log.w(TAG, "WakeLock failed", e)
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Throwable) {
        }
        wakeLock = null
    }

    // ─────────────────────────── Secret settings access ───────────────────────────

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val corner = dp(SECRET_CORNER_DP)
            if (ev.x < corner && ev.y < corner) {
                val now = SystemClock.elapsedRealtime()
                if (now - firstTapAt > SECRET_TAP_WINDOW_MS) {
                    firstTapAt = now
                    tapCount = 0
                }
                tapCount++
                if (tapCount >= SECRET_TAPS) {
                    tapCount = 0
                    firstTapAt = 0L
                    showSettingsDialog(firstRun = false)
                    return true
                }
            } else {
                tapCount = 0
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        when (event.keyCode) {
            KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_0,
            KeyEvent.KEYCODE_NUMPAD_0,
            KeyEvent.KEYCODE_SETTINGS -> {
                if (event.action == KeyEvent.ACTION_UP) showSettingsDialog(firstRun = false)
                return true
            }
            KeyEvent.KEYCODE_BACK -> return true // kiosk: swallow Back
        }
        return super.dispatchKeyEvent(event)
    }

    // ─────────────────────────── Settings dialog ───────────────────────────

    @Suppress("DEPRECATION")
    private fun showSettingsDialog(firstRun: Boolean) {
        if (settingsDialog?.isShowing == true) return

        val input = EditText(this).apply {
            setText(serverUrl() ?: "https://")
            setSelection(text.length)
            hint = getString(R.string.url_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_DONE
            isSingleLine = true
            textDirection = View.TEXT_DIRECTION_LTR
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }

        val builder = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(R.string.settings_title)
            .setMessage(R.string.settings_message)
            .setView(container)
            .setCancelable(!firstRun)
            .setPositiveButton(R.string.save, null)
            .setNeutralButton(R.string.android_settings, null)
        if (!firstRun) builder.setNegativeButton(R.string.cancel, null)

        val dialog = builder.create()
        dialog.setCanceledOnTouchOutside(false)
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val url = normalizeUrl(input.text.toString())
                if (url == null) {
                    input.error = getString(R.string.invalid_url)
                    return@setOnClickListener
                }
                prefs.edit().putString(KEY_URL, url).apply()
                dialog.dismiss()
                pageFailed = false
                hideOverlay()
                if (webView == null) createWebView()
                loadServer()
                requestAutostartPermissions()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                } catch (e: Throwable) {
                    Log.w(TAG, "No settings app", e)
                }
            }
            input.requestFocus()
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.performClick()
                true
            } else {
                false
            }
        }
        dialog.setOnDismissListener {
            settingsDialog = null
            hideSystemBars()
        }
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        settingsDialog = dialog
        dialog.show()
    }

    private fun normalizeUrl(raw: String): String? {
        var value = raw.trim()
        if (value.isEmpty() || value == "https://" || value == "http://") return null
        if (!value.contains("://")) value = "http://$value"
        val uri = try {
            Uri.parse(value)
        } catch (_: Throwable) {
            return null
        }
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return null
        if (uri.host.isNullOrBlank()) return null
        return value
    }

    /** Android 10+ blocks activity starts from the background unless "Display over other apps" is granted. */
    @Suppress("DEPRECATION")
    private fun requestAutostartPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(R.string.autostart_title)
                .setMessage(R.string.autostart_message)
                .setPositiveButton(R.string.open_settings) { _, _ -> openOverlaySettings() }
                .setNegativeButton(R.string.later, null)
                .setOnDismissListener { hideSystemBars() }
                .show()
        }
    }

    private fun openOverlaySettings() {
        val specific = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        try {
            startActivity(specific)
        } catch (_: Throwable) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            } catch (e: Throwable) {
                Log.w(TAG, "Overlay settings not available on this device", e)
            }
        }
    }

    // ─────────────────────────── Utils ───────────────────────────

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

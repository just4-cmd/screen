# 📺 Signage Player — تطبيق أندرويد Kiosk لشاشات الإعلانات

تطبيق Native خفيف (Kotlin) يعرض صفحة المشغّل (مثل `https://your-domain/player/`) بملء الشاشة 24/7.
يعمل على الهواتف، التابلت، صناديق TV Box و Android TV — من **Android 5.0 (API 21)** فما فوق.

## ✨ المزايا
| الميزة | التفاصيل |
|---|---|
| ملء شاشة دائم | Immersive Sticky + إعادة إخفاء الأشرطة تلقائياً لو ظهرت |
| الشاشة لا تنطفئ | `FLAG_KEEP_SCREEN_ON` + WakeLock + فتح فوق شاشة القفل |
| WebView كامل | JavaScript، LocalStorage، IndexedDB، Service Workers، تشغيل الفيديو تلقائياً بدون لمس |
| بدون مؤشر/أشرطة تمرير | إخفاء مؤشر الماوس (PointerIcon + CSS) وأشرطة التمرير |
| أول تشغيل | نافذة لإدخال رابط المشغّل وحفظه |
| إعدادات سرية | **5 ضغطات** في الزاوية العلوية اليسرى خلال 3 ثوانٍ، أو زر **MENU** / **0** / **Settings** في الريموت |
| تشغيل تلقائي | عند الإقلاع (`BOOT_COMPLETED`, `QUICKBOOT_POWERON`) وبعد تحديث التطبيق (`MY_PACKAGE_REPLACED`) |
| انقطاع الشبكة | لا تظهر صفحة خطأ أندرويد أبداً؛ شاشة سوداء + إعادة محاولة كل 10 ثوانٍ، وتحميل من الكاش عند عدم وجود إنترنت، وإعادة محاولة فورية عند رجوع الشبكة |
| Watchdog | إعادة بناء الـ WebView عند انهياره (Render Process Gone / نفاد الذاكرة)، وكشف تجمّد الصفحة (نبضة JS كل 30 ث)، وإعادة تشغيل التطبيق تلقائياً بعد أي Crash |
| زر الرجوع | معطّل (Kiosk) |

---

## 📁 هيكلية المشروع
```
SignagePlayer/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── .github/workflows/build-apk.yml
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/signage/player/
        │   ├── MainActivity.kt
        │   └── BootReceiver.kt
        └── res/
            ├── drawable/ (ic_launcher, ic_notification, banner للـ TV)
            ├── values/ (strings إنجليزي + themes)
            ├── values-ar/strings.xml
            ├── values-v28/themes.xml
            └── xml/network_security_config.xml
```

---

## 🏗️ بناء الـ APK عبر GitHub Actions (بدون Android Studio)

1. أنشئ مستودعاً جديداً على GitHub (يمكن أن يكون Private) وارفع كل الملفات كما هي:
   ```bash
   cd SignagePlayer
   git init && git add . && git commit -m "Signage Player"
   git branch -M main
   git remote add origin https://github.com/USERNAME/signage-player.git
   git push -u origin main
   ```
2. افتح تبويب **Actions** في المستودع → سيبدأ "Build APK" تلقائياً (أو اضغط **Run workflow**).
3. بعد انتهائه (≈ 3–5 دقائق) افتح الـ Run → قسم **Artifacts** → حمّل **app-release** (ملف zip بداخله `app-release.apk`).
4. لإصدار رسمي: أنشئ Tag مثل `v1.0` → يُرفق الـ APK تلقائياً في صفحة **Releases**:
   ```bash
   git tag v1.0 && git push origin v1.0
   ```

### 🔐 توقيع ثابت (مهم للتحديثات)
بدون إعداد هذه الخطوة، يُوقَّع كل Build بمفتاح مؤقت مختلف ⇒ لازم تحذف التطبيق القديم قبل تثبيت الجديد.
لتثبيت التحديثات فوق القديم مباشرة، أنشئ مفتاحاً **مرة واحدة** واحفظه في GitHub Secrets:

```bash
keytool -genkeypair -v -keystore release.jks -alias signage \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "STORE_PASSWORD" -keypass "KEY_PASSWORD" \
  -dname "CN=Signage Player"

base64 -w 0 release.jks > release.jks.b64      # على macOS:  base64 -i release.jks > release.jks.b64
```
في المستودع: **Settings → Secrets and variables → Actions → New repository secret**:

| الاسم | القيمة |
|---|---|
| `KEYSTORE_BASE64` | محتوى ملف `release.jks.b64` |
| `SIGNING_STORE_PASSWORD` | STORE_PASSWORD |
| `SIGNING_KEY_ALIAS` | `signage` |
| `SIGNING_KEY_PASSWORD` | KEY_PASSWORD |

⚠️ احتفظ بنسخة من `release.jks` وكلمات المرور في مكان آمن — لو ضاع المفتاح لن تستطيع تحديث التطبيقات المثبتة.
رقم الإصدار (`versionCode`) يزيد تلقائياً مع كل Build، لذا كل APK جديد يُثبَّت فوق السابق.

### البناء محلياً (اختياري)
مع Android Studio: افتح المجلد ← Build ← Build APK.
أو من سطر الأوامر (JDK 17 + Android SDK + Gradle 8.11):
```bash
gradle assembleRelease
# الناتج: app/build/outputs/apk/release/app-release.apk
```

---

## 📲 التثبيت على الشاشة

**الطريقة 1 — USB/ADB (الأسرع لعدة أجهزة):**
```bash
adb connect 192.168.1.50:5555          # لو الجهاز على الشبكة ومفعّل فيه ADB
adb install -r app-release.apk
```
**الطريقة 2:** انسخ الـ APK على فلاشة، وافتحه بمدير الملفات (فعّل "السماح بالتثبيت من مصادر غير معروفة").
**الطريقة 3 (Android TV):** تطبيق *Downloader* أو *Send Files to TV*.

### ✅ الإعداد بعد التثبيت (مرة واحدة لكل شاشة)
1. افتح التطبيق → أدخل رابط المشغّل، مثال: `https://signage.example.com/player/` → **حفظ**.
   (لسيرفر محلي بدون SSL: `http://192.168.1.10:3000/player/` — مسموح).
2. **أندرويد 10 فما فوق:** سيطلب التطبيق إذن **"الظهور فوق التطبيقات الأخرى"** — فعّله؛ هذا شرط من أندرويد ليتمكن التطبيق من فتح نفسه بعد الإقلاع.
   - إن لم تظهر هذه الصفحة (بعض أجهزة Android TV) يستخدم التطبيق بديلاً تلقائياً: إشعار Full-Screen يفتح المشغّل. وافق على إذن الإشعارات لو طُلب (أندرويد 13+).
   - على Android TV عبر ADB يمكن منح الإذن مباشرة:
     `adb shell appops set com.signage.player SYSTEM_ALERT_WINDOW allow`
3. من إعدادات الجهاز:
   - عطّل **حافظ الشاشة/Daydream** و **السكون**.
   - عطّل **تحسين البطارية** للتطبيق (Battery optimization → Don't optimize) — مهم على التابلت والهواتف.
   - في بعض أجهزة Xiaomi/Huawei/Oppo: فعّل **Autostart** للتطبيق من إعدادات الأمان.
   - في TV Box: فعّل **Power on after AC loss / Auto power on** إن وُجد.
4. أعد تشغيل الجهاز للتجربة: يجب أن يفتح المشغّل تلقائياً خلال ثوانٍ من الإقلاع.

### 🔒 Kiosk كامل (اختياري)
لمنع الخروج بزر Home نهائياً، اجعل الجهاز **Device Owner** (على جهاز بعد Factory Reset وبدون حساب Google) أو استخدم إعدادات "Screen pinning" في أندرويد. أبسط بديل عملي: إخفاء الجهاز خلف الشاشة واستخدام الريموت فقط.

---

## 🛠️ الاستخدام اليومي
- **فتح الإعدادات:** 5 ضغطات سريعة في الزاوية العلوية اليسرى، أو زر **MENU** / **0** في الريموت.
  من النافذة: تغيير الرابط، أو زر **إعدادات أندرويد** للوصول لإعدادات النظام.
- **السجلات (للتشخيص):** `adb logcat -s SignagePlayer SignageBoot`

## ❓ حل المشاكل
| المشكلة | الحل |
|---|---|
| لا يفتح بعد الإقلاع (أندرويد 10+) | فعّل "الظهور فوق التطبيقات"، أو أمر `adb shell appops` أعلاه، وعطّل تحسين البطارية. |
| الفيديو لا يعمل | استخدم MP4 بترميز H.264، وحدّث **Android System WebView** من المتجر (الإصدارات القديمة جداً على بعض TV Box لا تدعم Service Workers جيداً). |
| شاشة سوداء مع "جاري الاتصال" | الرابط خاطئ أو السيرفر متوقف؛ التطبيق يعيد المحاولة كل 10 ثوانٍ تلقائياً. |
| رسالة "App not installed" عند التحديث | التوقيع مختلف — احذف القديم أو اضبط Secrets التوقيع الثابت. |
